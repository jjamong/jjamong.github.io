package com.jjamong.hormone.common.jwt;

public enum JwtResultType {
   VALID_JWT, EXPIRED_JWT, INVALID_JWT
}
