import React from 'react';
import Styled from 'styled-components/native';

import TodoListView from './TodoListView';
import AddTodo from './AddTodo';

const Continer = Styled.View`
    flex: 1;
`

const Todo: () => React$Node = () => {
  return (
    <Continer>
        <TodoListView />
        <AddTodo />
    </Continer>
  );
};
export default Todo;
