import React, { Fragment } from 'react';
import Styled from 'styled-components/native'

//const Container = Styled.TouchableOpacity``;
const Container = Styled.SafeAreaView`
    flex: 1;
`;
//const Icon = Styled.Image'';

const CountLabel = Styled.Text`
    font-size: 24px;
    font-weight: bold;
`;

interface Props {
    iconName: 'plus' | 'minus';
    onPress?: () => void;
}

//const Button = ({iconName, onPress}: Props) => {
const Button = () => {
    return (
        <Container>
            <CountLabel>ase</CountLabel>
        </Container>
    );
};

export default Button;